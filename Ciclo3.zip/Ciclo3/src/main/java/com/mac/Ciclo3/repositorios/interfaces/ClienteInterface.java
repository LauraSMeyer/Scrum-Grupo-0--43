package com.mac.Ciclo3.repositorios.interfaces;

import com.mac.Ciclo3.modelos.Cliente;
import org.springframework.data.repository.CrudRepository;

public interface ClienteInterface extends CrudRepository<Cliente,Long> {
}
